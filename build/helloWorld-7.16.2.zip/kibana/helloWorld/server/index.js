"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

var _helloWorldRoute = _interopRequireDefault(require("./routes/helloWorldRoute"));

function _default(kibana) {
  return new kibana.Plugin({
    id: 'helloWorld',
    configPrefix: 'helloWorld',
    publicDir: `${__dirname}/public`,
    require: ['kibana', 'elasticsearch'],

    init(server) {
      // Adicione aqui o código de inicialização do plugin
      (0, _helloWorldRoute.default)(server);
    }

  });
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzIl0sIm5hbWVzIjpbImtpYmFuYSIsIlBsdWdpbiIsImlkIiwiY29uZmlnUHJlZml4IiwicHVibGljRGlyIiwiX19kaXJuYW1lIiwicmVxdWlyZSIsImluaXQiLCJzZXJ2ZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOztBQUVlLGtCQUFVQSxNQUFWLEVBQWtCO0FBQy9CLFNBQU8sSUFBSUEsTUFBTSxDQUFDQyxNQUFYLENBQWtCO0FBQ3ZCQyxJQUFBQSxFQUFFLEVBQUUsWUFEbUI7QUFFdkJDLElBQUFBLFlBQVksRUFBRSxZQUZTO0FBR3ZCQyxJQUFBQSxTQUFTLEVBQUcsR0FBRUMsU0FBVSxTQUhEO0FBSXZCQyxJQUFBQSxPQUFPLEVBQUUsQ0FBQyxRQUFELEVBQVcsZUFBWCxDQUpjOztBQUt2QkMsSUFBQUEsSUFBSSxDQUFDQyxNQUFELEVBQVM7QUFDWDtBQUNBLG9DQUFnQkEsTUFBaEI7QUFDRDs7QUFSc0IsR0FBbEIsQ0FBUDtBQVVEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGhlbGxvV29ybGRSb3V0ZSBmcm9tICcuL3JvdXRlcy9oZWxsb1dvcmxkUm91dGUnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAoa2liYW5hKSB7XG4gIHJldHVybiBuZXcga2liYW5hLlBsdWdpbih7XG4gICAgaWQ6ICdoZWxsb1dvcmxkJyxcbiAgICBjb25maWdQcmVmaXg6ICdoZWxsb1dvcmxkJyxcbiAgICBwdWJsaWNEaXI6IGAke19fZGlybmFtZX0vcHVibGljYCxcbiAgICByZXF1aXJlOiBbJ2tpYmFuYScsICdlbGFzdGljc2VhcmNoJ10sXG4gICAgaW5pdChzZXJ2ZXIpIHtcbiAgICAgIC8vIEFkaWNpb25lIGFxdWkgbyBjw7NkaWdvIGRlIGluaWNpYWxpemHDp8OjbyBkbyBwbHVnaW5cbiAgICAgIGhlbGxvV29ybGRSb3V0ZShzZXJ2ZXIpO1xuICAgIH1cbiAgfSk7XG59XG4iXX0=