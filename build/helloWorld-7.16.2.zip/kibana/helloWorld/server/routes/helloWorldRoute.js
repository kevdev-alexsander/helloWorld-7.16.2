"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _default;

function _default(server) {
  const router = server.newRouter();
  router.get({
    path: '/api/helloWorld/hello',
    validate: false
  }, (context, request, response) => {
    return response.ok({
      body: {
        message: 'Hello World!'
      }
    });
  });
  server.route(router);
}

module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlbGxvV29ybGRSb3V0ZS50cyJdLCJuYW1lcyI6WyJzZXJ2ZXIiLCJyb3V0ZXIiLCJuZXdSb3V0ZXIiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwib2siLCJib2R5IiwibWVzc2FnZSIsInJvdXRlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWUsa0JBQVVBLE1BQVYsRUFBa0I7QUFDN0IsUUFBTUMsTUFBTSxHQUFHRCxNQUFNLENBQUNFLFNBQVAsRUFBZjtBQUVBRCxFQUFBQSxNQUFNLENBQUNFLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUUsdUJBRFI7QUFFRUMsSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQUtFLENBQUNDLE9BQUQsRUFBVUMsT0FBVixFQUFtQkMsUUFBbkIsS0FBZ0M7QUFDOUIsV0FBT0EsUUFBUSxDQUFDQyxFQUFULENBQVk7QUFBRUMsTUFBQUEsSUFBSSxFQUFFO0FBQUVDLFFBQUFBLE9BQU8sRUFBRTtBQUFYO0FBQVIsS0FBWixDQUFQO0FBQ0QsR0FQSDtBQVVBWCxFQUFBQSxNQUFNLENBQUNZLEtBQVAsQ0FBYVgsTUFBYjtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHNlcnZlcikge1xuICAgIGNvbnN0IHJvdXRlciA9IHNlcnZlci5uZXdSb3V0ZXIoKTtcbiAgXG4gICAgcm91dGVyLmdldChcbiAgICAgIHtcbiAgICAgICAgcGF0aDogJy9hcGkvaGVsbG9Xb3JsZC9oZWxsbycsXG4gICAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICAgIH0sXG4gICAgICAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogeyBtZXNzYWdlOiAnSGVsbG8gV29ybGQhJyB9IH0pO1xuICAgICAgfVxuICAgICk7XG4gIFxuICAgIHNlcnZlci5yb3V0ZShyb3V0ZXIpO1xuICB9XG4gICJdfQ==